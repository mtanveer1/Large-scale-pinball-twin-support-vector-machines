% Author : Rahul Choudhary

%--------------Description--------------------
% Function to calculate accuracy, non-zero
% dual variables and training time for
% IPTWSVM  for non-linear case.  
%---------------------------------------------
function [accuracy, non_zero_dual_variables, training_time, lambda2] = IPTWSVM_Kernel(A, B, X_Test, Y_Test, c1, c3, gamma, tau,t_opt,f_opt)
%% Input
% A, B denote the samples of Positive and negative class
% X_Test, Y_Test denote the testing data samples and their labels 
% c1, c3, gamma, tau,t_opt,f_opt are the parameters. For details please refer to the following paper
%% Tanveer, M., Aruna Tiwari, Rahul Choudhary, and M. A. Ganaie. "Large-scale pinball twin support vector machines." Machine learning (2021): 1-24.


tic;
% tau1 = tau2 = tau
training_time = 0;
non_zero_dual_variables = zeros(2, 1);

m1 = size(A, 1);
m2 = size(B, 1);

e1 = ones(m1, 1);
e2 = ones(m2, 1);

Kaa=Rec_Kernel(A,A',gamma);

Kab=Rec_Kernel(A,B',gamma);

Kbb=Rec_Kernel(B,B',gamma);

Q = [Kaa + c3.*eye(m1)  Kab; Kab'  Kbb] + ones(m1 + m2, m1 + m2);

f = [zeros(m1, 1) ; -e2*c3];

[U] = qpSOR_new(Q, f, t_opt, -tau*c1, c1, m1, f_opt);

clear Q f

mu1 = U(1: m1, :);
lambda1 = U(m1 + 1: end, :);

%---------Original ISPTWSVM with Sparse Pinball function for 2nd class---------
c2 = c1;
c4 = c3;

%tic;

E = [ones(m2, m2) -ones(m2, m1); -ones(m1, m2) ones(m1, m1)];


Q = [Kbb + c4.*eye(m2)  -Kab' ; -Kab  Kaa] + E;

f = [zeros(m2, 1); -e1*c4];

[U] = qpSOR_new(Q, f, t_opt, -tau*c2, c2, m2, f_opt);

clear Q f E Kaa Kab Kbb


mu2 = U(1: m2, :);
lambda2 = U(m2 + 1: end, :);

training_time = training_time + toc;

Kta=Rec_Kernel(X_Test,A',gamma);

Ktb=Rec_Kernel(X_Test,B',gamma);

dist1 = abs((Kta*mu1 + Ktb*lambda1 + e1'*mu1 + e2'*lambda1)./c3);
dist2 = abs((Kta*lambda2 - Ktb*mu2 + e1'*lambda2 - e2'*mu2)./c4);

accuracy = 0;

Y_Predicted = ones(size(X_Test, 1), 1);

Y_Predicted(dist1 > dist2,:)=-1;

accuracy = (sum(Y_Predicted == Y_Test))/(size(Y_Test, 1));

end