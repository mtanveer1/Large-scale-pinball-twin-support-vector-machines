% Author : Rahul Choudhary

function [bestalpha] = qpSOR_new(Q, f, t, lb, ub, zeroRange, smallvalue)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Improved Pin TWSVM 
%
%       bestalpha = qpSOR_new(Q, t, lb, ub, smallvalue)
% 
%       Input:
%               Q     - Hessian matrix(Require positive definite). 
%
%               f     - Vector for linear part of quadratic problem.
%
%               t     - (0,2) Paramter to control training.
%
%               lb    - Lower bound
%
%               ub    - Upper bound
%
%               zeroRange  - Number of alphas from start for which there are no constraints
%
%               smallvalue - Termination condition
%
%       Output:
%               bestalpha - Solutions of QPPs.
% 
% Reference:
%   Yuan-Hai Shao, Wei-Jie Chen and Nai-Yang Deng, "Nonparallel support 
%   vector machine" Submitted 2013
%
%   version 1.0 --Apr/2013 
%
%   Written by Wei-Jie Chen (wjcper2008@126.com)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initailization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[m,n]=size(Q);
alpha0=zeros(m,1);
L=tril(Q);
E=diag(Q);
twinalpha=alpha0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute alpha
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:n
%     i=i+1;
%try
    twinalpha(j,1)=alpha0(j,1)-(t/E(j,1))*(Q(j,:)*twinalpha(:,1) + f(j) +L(j,:)*(twinalpha(:,1)-alpha0));
%catch
  %  disp('ERROR')
%end
    if j > zeroRange
        if twinalpha(j,1)<lb
            twinalpha(j,1)=lb;
        elseif twinalpha(j,1) > ub
            twinalpha(j,1)=ub;
        else
            ;
        end
    end
end

alpha=[alpha0, twinalpha];
iteration = 0;
while norm(alpha(:,2)-alpha(:,1))>smallvalue && iteration < 50
    for j=1:n
        twinalpha(j,1)=alpha(j,2)-(t/E(j,1))*(Q(j,:)*twinalpha(:,1) + f(j) +L(j,:)*(twinalpha(:,1)-alpha(:,2)));
        if j > zeroRange
            if twinalpha(j,1)<lb
                twinalpha(j,1)=lb;
            elseif twinalpha(j,1)>ub
                twinalpha(j,1)=ub;
            else
                ;
            end
        end
    end
    alpha(:,1)=[];
    alpha=[alpha,twinalpha];
    iteration = iteration + 1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
bestalpha=alpha(:,2);


